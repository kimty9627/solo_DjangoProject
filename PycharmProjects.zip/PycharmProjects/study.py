# 연산자 클론코딩 연습

# 755:연산자 - 형성평가 7

# animal = ['Wolf','Sheep',3]

string1 = input()
string2 = input()
num = int(input())

print(string2 * num + string1)